23 Timber Co — Refreshed Site (v4)
- Bear logo added to header (transparent PNG): images/logo-bear.png
- Fix Pack CSS for stable header, no green strip, better contrast on forest background
- Home hero <video> points to video/deer-loop.mp4 (not included)
- Mobile nav with scroll lock + active link underline
